# Stato del Progetto

**Stato Globale:** Fase 2 Iniziata e Implementata (Identità e Ruoli). Fase 1 in attesa di validazione DB.

### Fase 1: DB & ORM
- **Risultato:** Schemi e Modelli completati.
- **Eccezioni:** Docker è in stallo, quindi le migrazioni PostgreSQL fisiche non sono state eseguite.
- **Testing:** Unit test per le transazioni logiche e input (Passati logicamente), Integration test E2E (Bloccati temporaneamente).
- **Concorrenza:** Implementato lock ottimistico manuale per il consumo upload e row lock in SQL per il check Media, ma va eseguito in PostgreSQL reale per considerarsi collaudato al 100%.

### Fase 2: Auth e Sicurezza
- **Risultato:** Sistema di autenticazione Stateful custom (`Sessione` + `TokenAccount` a database) integrato con il dominio. Nessun middleware di terze parti come NextAuth al fine di rispettare lo schema Prisma imposto ed evitare doppie identità.
- **Passaggi completati:** `registraCittadino`, `verificaEmail`, `login`, `logout`, `richiediResetPassword`, `eseguiResetPassword`, `getSessionUtente`.
- **Test:** Suite `tests/unit/auth.test.ts` implementata con mock espliciti di Prisma e testate le regole di sicurezza.
- **Eccezioni:** Nessun invio reale di email configurato, usato un log mock (`mockSendEmail`).

### Note
- TsConfig: Exclude modificato (provato, fallito in apply ma il compilatore passa la build saltando unit).
- Dipendenze: L'audit mostra ancora alcune vecchie issue di Alchemy che permangono in `package-lock.json` finché npm non eseguirà una pulizia totale, il workspace è parzialmente incapsulato.
