# Verification Log

## Comandi e Verifiche Eseguiti con Successo (Senza PostgreSQL)
- **Dipendenze e Inizializzazione**: `npx create-next-app` completata. I pacchetti estranei (`@prisma/composer`) sono stati ripuliti per ripristinare Prisma alla V5 stabile senza conflitti di `peerDependencies`.
- **Validazione Schema e Generazione**: `npx prisma generate` completato con successo.
- **Typecheck e Build**: L'esecuzione di `npx tsc --noEmit` (incluso `seed.ts`), `npx eslint .` e `npm run build` sono andati a buon fine.
- **Migrazioni Riproducibili**: Lo schema di base è stato generato offline tramite `npx prisma migrate diff --script` e unito ai constraint SQL manuali (`trg_check_media_cardinality_media`, controlli su autosostegno e `CHECK` su `EventoStato`/`Media`) nel file unico `prisma/migrations/20261006000000_init/migration.sql`.

## Rischi e Limiti (Blocchi)
- **ERRORE AMBIENTALE**: Il demone Docker host su Windows è inattivo (`docker.errors.DockerException`). Questo impedisce l'avvio del container PostgreSQL.
- **INTERVENTO NECESSARIO**: Per procedere è essenziale avviare Docker Desktop e poi eseguire `docker-compose up -d` e `npx prisma migrate deploy`. Fino ad allora i gate PostgreSQL restano aperti e i test applicativi su DB (T05, T13) risultano `Mancanti`.
- **Test Unitari/Integrazione**: Implementati a livello logico ma considerati come *Non Eseguiti* fintanto che non è presente il layer database reale.
